﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace testSpcAlc
{
	public enum Operation
	{
		AddStudent,
		MultipleAddStudents,
		AddWork,
		MultipleAddWorks,
		AddGrade,
		UpdateGrade,
		PrintTable,
		ReadTable
	}
}
